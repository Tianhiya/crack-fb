# ✭ PREMIUM CRACK
#### Made With ❤️ By Dapunta  
``` 
Author :
    • Dapunta Khurayra X
  
Team Project HEKER HEKER BIUTIPUL :
    • Muhamad Rizal Fiansyah Id
    • Angga Kurniawan
    • Yayan XD
    • Boy Hamzah
    • Latip Harkat
    • Zacky Tricker
    • Sutan Ubay
    • Rizky Dev
    • Iqbal Dev
    • Aap Afandi
    • Fallen
    • Hanifan
```
#### ⇨  Feature Login
```
[✯] Login Cookies  
[✯] Login Token  
[✯] Cookies/Token Awet  
```
#### ⇨  Feature Crack
```
[✯] Crack From Friend, Public, Followers, Likers    
[✯] Crack Default/Manual Pass  
[✯] Crack Methode Api, Mbasic, Free FB  
[✯] Crack With TTL/DOB  
[✯] Crack Default 4 Country + 1 None
```
#### ⇨  Install Script On Termux
```
$ pkg update && upgrade  
$ termux-setup-storage  
$ pkg install python  
$ pkg install git  
$ pip install bs4  
$ pip install requests  
$ pip install mechanize  
$ pip install futures  
$ rm -rf premium  
$ git clone https://github.com/Dapunta/premium  
```
#### ⇨  Run Script
```
$ cd premium  
$ git pull  
$ python premium.py  
```
#### ⇨  Information
```
[!] Kenapa Cracknya Lemot Ngab? Sebab :
✯ ---> Crack Indonesia = 7 Pass
✯ ---> Crack India/Bangla = 7 Pass
✯ ---> Crack Pakistan = 6 Pass
✯ ---> Crack USA = 7 Pass
✯ ---> Crack None = 3 Pass
✯ ---> Kalau Mau Kenceng Dikit Pake (None) Aja

[!] Bedanya Metode Crack Apaan Ngab? Nih :
✯ ---> API = Pake Metode Lama, Cracknya Cepet Tapi Gampang Kena Spam, Sebab Udah Diupdate Sama Pihak Facebook
✯ ---> Mbasic = Metode Lama Yang Masih Valid Sampe Sekarang, Cracknya Lumayan Lambat, Tapi Jarang Kena Spam, Makanya Recommended
✯ ---> Free = Seperti Mbasic, Bedanya Ganti Tempat Login Aja, Cracknya Paling Lambat, Gak Kena Spam, Kemungkinan Dapet OK
✯ ---> TTL = (Tahun Tanggal Lahir), Bikin Kena Spam Aje, Tergantung Perangkat Sama Kartu Kalau Inimah
```

#### ⇨ Note
```
[!] Dapunta Tidak Pernah Membuat SC Berbayar
[!] SC Ini 100% Gratis, Resiko Atas Penyalahgunaan, Ditanggung Pengguna
[!] Recode? Silahkan, Asal Jangan Ganti Bot Follownya
[!] Dilarang Keras Memperjual Belikan File SC Ini
```
#### ⇨  Screenshot
![Premium Dapunta (1)](https://user-images.githubusercontent.com/76211798/128638195-04fcbc38-de70-4b74-8bb0-c9ccdbeea2a0.jpg)
