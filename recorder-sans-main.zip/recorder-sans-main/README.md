# ✭ ELITE CRACK
#### Dibuat Dengan ❤️ Oleh Dapunta & Rizal
```
Author:
- Sans nih bozz

```
#### ⇨  Fitur Login
```
[✯] Login Cookies  
[✯] Login Token  
[✯] Cookies/Token Awet  
```
#### ⇨  Fitur Crack
```
[✯] Crack Dari Teman, Public, Followers, Likers    
[✯] Crack Default/Manual Pass  
[✯] Crack Metode Api, Mbasic, Free FB  
[✯] Crack With TTL/DOB  
```
#### ⇨  Install Script Di Termux
```
$ termux-setup-storage  
   • Enter  
   • Ketik y Atau Pilih Izinkan  
$ termux-change-repo
   • Pilih Game Repository
      - Klik OK
   • Pilih Mirror By Grimler
      - Klik OK
$ pkg install python
$ pkg install git
$ pip install requests
$ pip install mechanize
$ pip install bs4
$ pip install futures
$ git clone https://github.com/sans/elite
 
```
#### ⇨  Menjalankan Script
```
$ cd elite
$ git pull
$ python elite.py
```
#### ⇨  Informasi
```
[!] Bedanya Metode Crack Apaan Ngab? Nih :
✯ ---> API = Pake Metode Lama, Cracknya Cepet Tapi Gampang Kena Spam, Sebab Udah Diupdate Sama Pihak Facebook, Not Recommended
✯ ---> Mbasic = Metode Lama Yang Masih Valid Sampe Sekarang, Cracknya Lumayan Lambat, Tapi Jarang Kena Spam, Makanya Recommended
✯ ---> Free = Seperti Mbasic, Bedanya Ganti Tempat Login Aja, Cracknya Paling Lambat, Gak Kena Spam, Kemungkinan Dapet OK
```
